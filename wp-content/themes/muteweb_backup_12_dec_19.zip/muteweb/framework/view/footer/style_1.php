<div class="top_footer" id="mob-app">
	<?php if($footer_in_grid == 'Yes' ) { ?>
			<div class="container">
		<?php } else{ ?>
			<div class="container-fluid">
		<?php } ?>	
		<div class="row">
			<div class="col-sm-12 col-md-6">
				<div class="d-flex">
					<div class="flex-grow-0">
						
						<?php if ( is_active_sidebar( 'footer-newsletter' ) ) { ?>
							<div class="">
								<p class="mb-2">Desktop Apps</p>
								<ul class="inner_logos preUl">
									<?php dynamic_sidebar( 'footer-newsletter' ); ?>
								</ul>
							</div>
						<?php } ?> 

						<?php if ( is_active_sidebar( 'footer-col-2' ) ) { ?>
							<div class="">
								<ul class="preUl">
									<?php dynamic_sidebar( 'footer-col-2' ); ?>
								</ul>
							</div>
						<?php } ?>

						<?php if ( is_active_sidebar( 'footer-col-4' ) ) { ?>
							<div class="mt-5">
                            <div class="footer-dpn mb-3">
						      <div class="btn-group dropup">
						        <button type="button" class="btn btn-down dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						        	<?php 
								    if ( class_exists( 'WPGlobus' ) ) { ?>
						          <img src="<?php echo site_url(); ?>/wp-content/uploads/2019/11/earth.svg"> <?php echo WPGlobus::Config()->en_language_name[ WPGlobus::Config()->language ];         }?>

						        </button>
						        <div class="dropdown-menu">
						           <?php 
								    if ( class_exists( 'WPGlobus' ) ) {
								        $flag = WPGlobus::Config()->flags_url . WPGlobus::Config()->flag[ WPGlobus::Config()->language ];
								        echo '<span class="current-language">' . WPGlobus::Config()->en_language_name[ WPGlobus::Config()->language ]. '</span>';
								        foreach( WPGlobus::Config()->enabled_languages as $lang ) {

								          if ( $lang == WPGlobus::Config()->language ) {
								            continue;
								          }
								          $flag = WPGlobus::Config()->flags_url . WPGlobus::Config()->flag[ $lang ];
								          echo '<a class="dropdown-item" href="' . WPGlobus_Utils::localize_current_url( $lang ). '">';
								          echo  WPGlobus::Config()->en_language_name[ $lang ];
								          echo '</a>';

								        }
								    }
								    ?>
						        </div>
						      </div>
						    </div>
							<ul class="preUl"><?php dynamic_sidebar( 'footer-col-4' ); ?></ul>
							</div>
						<?php } ?>
					</div>

					<!-- section 2 -->
					<div class="flex-grow-1">
						<?php if ( is_active_sidebar( 'footer-col-1' ) ) { ?>
							<div class="">
								<p class="mb-2">Mobile Apps</p>
								<ul class="inner_logos preUl">
									<?php dynamic_sidebar( 'footer-col-1' ); ?>
								</ul>
							</div>
						<?php } ?>
						<?php if ( is_active_sidebar( 'footer-col-3' ) ) { ?>
							<div class="">
								<ul class="preUl"><?php dynamic_sidebar( 'footer-col-3' ); ?></ul>
							</div>
						<?php } ?>
					</div>
				</div>

				<div class="d-flex mt-4">
				<?php if ( is_active_sidebar( 'footer-bottom' ) ) {  dynamic_sidebar( 'footer-bottom' ); } ?>
				</div>
			</div>
			<!-- end all content and links -->
			<div class="col-sm-12 col-md-6 contact-form-box">
				<h4>Contact Us</h4>
				<p class="mb-5">For complete accounting solution for your business</p>
				<?php echo do_shortcode('[contact-form-7 id="281" title="contact form"]'); ?>
			</div>

			
			
			
			
			
			<!-- <?php if ( is_active_sidebar( 'footer-col-5' ) ) { ?>
				<div class="col">
				<ul class="preUl"><?php dynamic_sidebar( 'footer-col-5' ); ?></ul>
				</div>
			<?php } ?>
			-->
		</div>
	</div>
</div>

<!-- <?php if ( is_active_sidebar( 'social-icons' ) ) { ?>
	<?php dynamic_sidebar( 'social-icons' );  ?>
<?php } ?> -->