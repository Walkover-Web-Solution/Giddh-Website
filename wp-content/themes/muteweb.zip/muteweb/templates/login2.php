<?php /* Template Name: login*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <meta name="google-signin-client_id" content="641015054140-3cl9c3kh18vctdjlrt9c8v0vs85dorv2.apps.googleusercontent.com">

</head>
<style>

.abcRioButton.abcRioButtonLightBlue {
    background-color: #5192F1 !important;
    height: 40px !important;
width:240px !important
}
a.btn.btn-outline-primary.p-0.g-signin2 {
       border-color: #ffffff !important;
}
.abcRioButtonIcon {
    background-color: #fff;
       padding: 11px !important;
}
span.abcRioButtonContents {
    color: #fff;
    line-height: 40px !important;
}
.login_right{
	background-image: url(http://staginglabs.in/v2giddh/wp-content/uploads/2019/11/Login-Page-Image.png);
	height: 100vh;
	justify-content: flex-start;
	    background-position: top right;
}
.login_left {
    background-color: #36396f;
    position: absolute;
    left: 0;
    height: 100%;
    width: 100%;
}
.logo_login {
    background-color: #36396e;
    height: 98px;
    display: flex;
    align-items: center;
    padding: 35px;
    position: relative;
}
.logo_login::before{
	content: "";
	position: absolute;
	bottom: 0;
	left: 0;

}
.giddh_login_inner {
    max-width: 476px;
    width: 90%;
    margin: 0 auto;
    border-radius: 8px;
    overflow: hidden;
}
.accounting_space h4 {
    color: #36396e;
    font-weight: 500;
    font-size: 20px;
}
.login_box {
    position: relative;
}
.giddh_login {
    margin-left: -245px;
        width: 495px;
}
.accounting_space {
    padding: 30px;
    border-radius: 10px 10px 0 0;
}
.list-unstyled a:hover {
    background-color: transparent;
}
.list-unstyled a {
    border-radius: 0;
}
.login-with {
    color: #36396e;
    font-size: .9em;
}
.login-with a {
   font-weight: 600;
    color: #36396e;
   text-decoration: none;
}
.account button {
    background-color: #e6e7e9;
    border-radius: 0;
    font-size: 14px;
    width: 108px;
    margin-left: 15px;
}
body .form-group input{
	border-radius: 0;
}
body .form-group input:focus,body .btn.focus, .btn:focus{
box-shadow: none;
border-color: #36396e;
}
#demo button {
    background-color: #36396d;
    margin-bottom: 15px;
    border-radius: 0;
}
@media(max-width: 767px){
	.giddh_login {
    margin: 0 auto;
}
}
@media(max-width: 575px){
	.logo_login,.accounting_space {
    padding: 20px;
}
}
</style>
<body>
<div class="login_box">
	<div class="row mx-0">
		<div class="col-md-6 col-lg-6 col-sm-12 col-12 px-0">
			<div class="login_left">	
			</div>
		</div>
		<div class="col-md-6 col-lg-6 col-sm-12 col-12 px-0">
			<div class="login_right d-flex align-items-center ">
				<div class="giddh_login">
		<div class="giddh_login_inner">
			<div class="logo_login"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/11/login-Page-Logo .png" alt="" width="141px"></div>
			<div class="accounting_space bg-white">
				<h4>Login to your secure accounting space</h4>
				<ul class="pl-0">
					<li class="list-unstyled pt-3"><a href="#" class="btn btn-outline-primary p-0 g-signin2" data-onsuccess="onSignIn">
            <!-- <img src="images/search.svg" height="20px" width="30"> -->
            <span class="p-2 d-inline-block bg-primary text-white w-70">Login with google</span></a></li>
				</ul>
				<p class="login-with mb-2">Login with<a href="#" data-toggle="collapse" data-target="#demo"> email and password</a></p>
				<form id="demo" class="collapse">
  <div class="form-group mb-2">
    <input type="email" class="form-control"placeholder="Email Id">
  </div>
  <div class="form-group mb-2">
    <input type="password" class="form-control" placeholder="Password">
  </div>
  <button type="submit" class="btn w-100 text-white">Login</button>
</form>
				<div class="d-flex align-items-center account">
					<p class="mb-0">Don't have an account?</p>
					<button type="button" class="btn "> signup</button>
				</div>
			</div>
		</div>
	</div>
		       
	        </div>
		</div>
	</div>

	
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://apis.google.com/js/platform.js" async defer></script>
<script>
function onSignIn(googleUser) {
  var profile = googleUser.getBasicProfile();
  console.log(profile);
}
$("#demo").submit(function(e) {
    e.preventDefault();
var uniqueKey= jQuery('#email').val();
var password= jQuery('#password').val();
jQuery.ajax({
  url: "https://api.giddh.com/v2/login-with-password",
 type: "POST",
  cache: false,
data: {"password": password , "uniqueKey": uniqueKey},
  success: function(html){
 
  }
});
});
</script>
</body>
</html>