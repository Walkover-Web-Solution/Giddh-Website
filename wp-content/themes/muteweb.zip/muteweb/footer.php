</main>

<!-- <section id="contact_section">
	<section class="container">
		<div class="row">
			<div class="col-md-2 col-sm-12">
				<h4>Queries</h4>
			</div>
			<div class="col-md-10 col-sm-12">
				[contact-form-7 id="107"]
			</div>
		</div>
	</section>
</section> -->

<?php 

	/*Footer Options */

	$footer_in_grid = get_option('footer_in_grid');

	$footer_bg_img = get_option('footer_bg_img');

	$footer_style = get_option('footer_style');

?>

<?php

	if (!empty($footer_bg_img) ){

		$footer_bg_class = 'footer_bg';	

	}

?>

	<footer class="<?php echo $footer_style; ?> <?php echo $footer_bg_class; ?>">

		<?php if ($footer_style == 'style_1' ){

			require_once(Mute_root_path.'/framework/view/footer/style_1.php');

		} elseif ($footer_style == 'style_2' ){

			require_once(Mute_root_path.'/framework/view/footer/style_2.php');

		}?>

	</footer>

    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/intlTelInput.js"></script>

<?php wp_footer(); ?>

<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/staginglabs.in\/giddh\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://staginglabs.in/giddh/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.4'></script>
<script type="text/javascript">	
	
	jQuery(".featuredpopup").click(function(){
		jQuery("#featuredHeading").html(jQuery(this).attr("data-heading"));
		jQuery("#featuredContent").html(jQuery(this).attr("data-body"));
		jQuery('#exampleModal').modal('show'); 		
	})	 

	// wpcf7-form
	document.addEventListener( 'wpcf7submit', function( event ) {
    console.log( "Fire!" );
	}, false );

</script>

<?php if ( is_front_page()) { ?>
  <!-- Modal start -->
<div class="modal fade" id="dubaiBannerModal" tabindex="-1" role="dialog" aria-labelledby="dubaiBannerModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body">
      <figure class="figure">
  <img src="http://staginglabs.in/v2giddh/wp-content/uploads/2019/11/home-page-banner.jpg" class="figure-img img-fluid" alt="Dubai Expo">
</figure>
      </div>
    </div>
  </div>
</div>
  <!-- Modal ends -->
<script type="text/javascript">
window.onload = function() {
  setTimeout(function(){
    jQuery('#dubaiBannerModal').modal('show');
  }, 5000)
}
</script>
<?php } ?>
</body>

<script>
function myFunction(x) {
  x.classList.toggle("change");
}

var input = document.querySelector("#phone");
window.intlTelInput(input, {
  onlyCountries: ["al", "ad", "at", "by", "be", "ba", "bg", "hr", "cz", "dk",
  "ee", "fo", "fi", "fr", "de", "gi", "gr", "va", "hu", "is", "ie", "it", "lv",
  "li", "lt", "lu", "mk", "mt", "md", "mc", "me", "nl", "no", "pl", "pt", "ro",
  "ru", "sm", "rs", "sk", "si", "es", "se", "ch", "ua", "gb","in"],
  utilsScript: "" // just for formatting/placeholders etc
});

jQuery("#phone").on("change",function(){

	//alert(this.value);
	//alert(jQuery(".iti__selected-flag").attr("title"));
	jQuery("#phone_number_change").val(this.value);
});


</script>

</html>