=== Empty P Tag ===

Contributors: husainahmedqureshi
Tags:wpautop, filter, editor, excerpt, Formatting, post content, remove p
Requires at least: 3.0
Tested up to: 5.0.3
License: HAQV1


This plugin hides empty paragraphs and make your butyfull design without breaking design.

== Description ==

This plugin remove extra p and br tags from the_content, the_excerpt and widget_text_content.

== Installation ==
To install "empty p tag" using the built-in plugin installer:

    1. Go to Plugins > Add New.
    2. Type in "empty p tag" in Search Plugins box or click a tag link below the screen.
    3. find the "empty p tag Plugin" in the list.
    4. Click Install Now to install the WordPress Plugin.


To install empty p tag manually:

   1. Download your WordPress Plugin to your desktop.
   2. If downloaded as a zip archive, extract the Plugin folder to your desktop.
   3. With your FTP program, upload the Plugin folder to the wp-content/plugins folder in your WordPress directory online.
   4. Go to Plugins screen and find the "empty p tag Plugin" in the list.
   5. Click Activate to activate it.


== Frequently Asked Questions ==

= How do Plugin turn off automatic p, br for a post? =

After plugin activation, WordPress will no longer attempt to add `<p>` and `<br>` tags to your posts (so you'll be responsible for adding these yourself).

= I upgraded the plugin and it lost my default settings! =

No, it didn't. Disable and re-enable the plugin and the setting should be updated to the new setting.


== Changelog ==

= 1.0.0 =
* First release

