/**
 * File: readme.txt
 *
 * @package WPGlobus\Builders\Elementor
 * @author Alex Gor(alexgff)
 */
 
The handling of post meta fields @see wpglobus\configs\elementor.json 
