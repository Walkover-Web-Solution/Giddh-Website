<div id="om-cybermonday-notice" class="info notice is-dismissible">
	<p>
		<img id="archie-peeking" src="<?php echo $this->url; ?>assets/css/images/dashboard-icon.png" alt="<?php esc_attr_e( 'Archie, OptinMonster Mascot', 'optin-monster-api' ); ?>">
		OptinMonster Black Friday / Cyber Monday special - <strong>35% off</strong> all purchases, upgrades and pre-payments!
		<a
		href="<?php echo esc_url( $data['url'] ); ?>"
		target="_blank" rel="noopener"
		title="Click here to claim your Cyber Monday deal."
		>Click here to claim your deal &rarr;</a>
	</p>
</div>
