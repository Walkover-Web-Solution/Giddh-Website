<style type="text/css">
	@font-face{
		font-family: 'archie';
		src: url('<?php echo $this->url . 'assets/fonts/archie.eot?velzrt'; ?>');
		src: url('<?php echo $this->url . 'assets/fonts/archie.eot?#iefixvelzrt'; ?>') format('embedded-opentype'),url('<?php echo $this->url . 'assets/fonts/archie.woff?velzrt'; ?>') format('woff'),url('<?php echo $this->url . 'assets/fonts/archie.ttf?velzrt'; ?>') format('truetype'),url('<?php echo $this->url . 'assets/fonts/archie.svg?velzrt#archie'; ?>') format('svg');
		font-weight: normal;
		font-style: normal;
	}
	#toplevel_page_optin-monster-api-settings .dashicons-before,
	#toplevel_page_optin-monster-api-settings .dashicons-before:before,
	#toplevel_page_optin-monster-api-welcome .dashicons-before,
	#toplevel_page_optin-monster-api-welcome .dashicons-before:before{
		font-family: 'archie';
		speak: none;
		font-style: normal;
		font-weight: normal;
		font-variant: normal;
		text-transform: none;
		line-height: 1;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}
	#toplevel_page_optin-monster-api-settings .dashicons-before:before,
	#toplevel_page_optin-monster-api-welcome .dashicons-before:before{
		content: "\e600";
		font-size: 38px;
		margin-top: -9px;
		margin-left: -8px;
	}
</style>
